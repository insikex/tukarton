#!/usr/bin/env python3
"""
TukarTON - Telegram Bot untuk Jual Beli TON Cryptocurrency

Entry point untuk menjalankan bot.
Semua logika telah diorganisir ke dalam modul-modul terpisah di folder tukarton/

Struktur folder:
tukarton/
├── __init__.py          # Package init
├── bot.py               # Main bot runner
├── config.py            # Konfigurasi dan pengaturan
├── constants.py         # Konstanta dan template teks
├── database/            # Operasi database
│   ├── __init__.py
│   ├── connection.py    # Koneksi database
│   ├── users.py         # Operasi user
│   ├── transactions.py  # Operasi transaksi
│   ├── referrals.py     # Sistem referral
│   ├── withdrawals.py   # Penarikan saldo
│   └── broadcast.py     # Broadcast
├── handlers/            # Handler Telegram
│   ├── __init__.py
│   ├── state.py         # Shared state
│   ├── commands.py      # /start, /help
│   ├── messages.py      # Pesan teks
│   ├── callbacks.py     # Callback query
│   ├── payments.py      # Setup pembayaran
│   ├── transactions.py  # Transaksi
│   ├── referrals.py     # Sistem referral
│   ├── admin.py         # Admin/owner
│   ├── broadcast.py     # Broadcast
│   └── errors.py        # Error handling
└── utils/               # Utilitas
    ├── __init__.py
    ├── price.py         # Harga TON
    ├── helpers.py       # Helper functions
    └── keyboards.py     # Keyboard generators

© 2026 Vyérru & Co.
"""

from tukarton import main

if __name__ == '__main__':
    main()
