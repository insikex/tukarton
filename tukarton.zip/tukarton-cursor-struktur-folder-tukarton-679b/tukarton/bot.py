"""
Main bot runner untuk TukarTON
Menggabungkan semua komponen dan menjalankan bot
"""

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters
)

from .config import (
    TELEGRAM_BOT_TOKEN,
    MIN_TON,
    MAX_TRANSACTION_IDR,
    MARGIN_PER_TON,
    ADMIN_USERNAME,
    logger
)
from .database import init_database
from .handlers import (
    start,
    help_command,
    handle_message,
    button_callback,
    error_handler
)
from .handlers.broadcast import handle_broadcast_command, handle_broadcast_with_image


def main():
    """Fungsi utama untuk menjalankan bot"""
    
    print("=" * 50)
    print("🚀 TON Exchange Bot - Modular Version")
    print("=" * 50)
    
    init_database()
    print("✅ Database initialized")
    
    print(f"Min TON: {MIN_TON}")
    print(f"Max Transaction: Rp {MAX_TRANSACTION_IDR:,}")
    print(f"Margin: Rp {MARGIN_PER_TON:,}")
    print(f"Admin: @{ADMIN_USERNAME}")
    print("=" * 50)
    
    if TELEGRAM_BOT_TOKEN == "TELEGRAM_BOT_TOKEN_ANDA":
        print("❌ ERROR: Silakan ganti TELEGRAM_BOT_TOKEN dengan token bot Anda!")
        print("   Dapatkan token baru dari @BotFather di Telegram")
        return
    
    print("✅ Bot aktif...")
    print("=" * 50)
    
    try:
        application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
        
        # Command handlers
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CommandHandler("help", help_command))
        application.add_handler(CommandHandler("broadcast", handle_broadcast_command))
        
        # Handler untuk broadcast dengan gambar (caption dimulai dengan /broadcast)
        application.add_handler(MessageHandler(
            filters.PHOTO & filters.CaptionRegex(r'^/broadcast'),
            handle_broadcast_with_image
        ))
        
        # Callback query handler
        application.add_handler(CallbackQueryHandler(button_callback))
        
        # Message handlers
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
        
        # Handler untuk foto (selain broadcast dengan caption) - untuk bukti transfer
        application.add_handler(MessageHandler(
            filters.PHOTO & ~filters.CaptionRegex(r'^/broadcast'), 
            handle_message
        ))
        
        # Error handler
        application.add_error_handler(error_handler)
        
        # Run the bot
        application.run_polling(allowed_updates=Update.ALL_TYPES)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        logger.error(f"Bot error: {e}", exc_info=True)


if __name__ == '__main__':
    main()
