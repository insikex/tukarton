"""
TukarTON - Telegram Bot untuk Jual Beli TON Cryptocurrency

Bot ini memungkinkan pengguna untuk menjual TON dan menerima pembayaran
dalam Rupiah melalui berbagai metode pembayaran.

© 2026 Vyérru & Co.
"""

__version__ = "1.0.0"
__author__ = "Vyérru & Co."

from .bot import main

__all__ = ['main']
