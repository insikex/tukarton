"""
Konstanta dan template teks untuk bot TukarTON
"""

from .config import COPYRIGHT_TEXT, ADMIN_USERNAME

# ============================================================
# TEXT TEMPLATES
# ============================================================
TEXTS = {
    'welcome': "Selamat datang {user_greeting} di @tukartonbot\n\nJual TON 💎 Anda dan Terima Rupiah dengan Cepat dan Aman\n\nGunakan menu button di bawah untuk memulai." + COPYRIGHT_TEXT,
    
    'setup_payment_required': "⚠️ <b>Atur Metode Pembayaran</b>\n\n<i>Sebelum menjual TON, silakan atur metode pembayaran terlebih dahulu.</i>" + COPYRIGHT_TEXT,
    
    'select_payment_method': "💳 <b>Pilih Metode Pembayaran</b>\n\n<i>Pilih metode pembayaran untuk menerima dana:</i>",
    
    'select_bank': "🏦 <b>Pilih Bank</b>\n\n<i>Biaya admin:</i>\n• BCA, BRI, BNI, Mandiri: Rp 2.500\n• SeaBank: <b>Gratis</b>",
    
    'select_ewallet': "📱 <b>Pilih E-Wallet</b>\n\n<i>Biaya admin: Rp 1.200</i>",
    
    'input_account_name': "💳 <b>Metode:</b> {method}\n\n<i>Masukkan nama pemilik rekening:</i>\nContoh: Budi Santoso",
    
    'input_account_number': "💳 <b>Metode:</b> {method}\n👤 <b>Nama:</b> {name}\n\n<i>Masukkan nomor rekening:</i>\nContoh: 1234567890",
    
    'payment_method_saved': "✅ <b>Metode Pembayaran Tersimpan</b>\n\n💳 <b>Metode:</b> {method}\n👤 <b>Nama:</b> {name}\n🔢 <b>Nomor:</b> <code>{number}</code>\n\n<i>Sekarang Anda dapat menjual TON.</i>" + COPYRIGHT_TEXT,
    
    'input_ton_amount': "💎 <b>Jual Toncoin</b>\n\n💰 <b>Harga beli:</b> Rp {price:,.0f}/TON\n📊 <b>Minimum:</b> {min_ton} TON\n🔴 <b>Maksimal:</b> {max_ton} TON (≈ Rp {max_idr:,.0f})\n\n<i>Masukkan jumlah TON:</i>",
    
    'send_ton_instruction': "📋 <b>Detail Transaksi</b>\n\n💎 <b>Jumlah TON:</b> {ton_amount}\n💰 <b>Harga:</b> Rp {price_per_ton:,.0f}/TON\n📊 <b>Biaya admin:</b> Rp {fee:,.0f}\n─────────────\n💵 <b>Total diterima:</b> Rp {total:,.0f}\n\n<b>📤 Alamat Tujuan:</b>\n<code>{wallet}</code>\n\n⚠️ <b>PENTING - MEMO OTOMATIS:</b>\n<code>{memo}</code>\n\n💡 <b>Cara Bayar:</b>\n️ • Klik tombol <b>💎 Bayar Sekarang</b>\n • Aplikasi TON Wallet akan terbuka otomatis\n • Memo/Comment sudah terisi otomatis: <code>{memo}</code>\n • Periksa jumlah TON: <b>{ton_amount}</b>\n • Konfirmasi pembayaran\n • Klik <b>✅ Sudah Kirim</b> dan upload bukti\n\n⚠️ <b>Catatan Penting:</b>\n• Jangan ubah memo/comment\n• Jangan kirim dari exchange\n• Pastikan jaringan TON\n• Tanpa memo = transfer ditolak!",
    
    'waiting_payment_proof': "📸 <b>Kirim Bukti Transfer</b>\n\n<i>Upload screenshot yang menampilkan:</i>\n• Jumlah TON\n• Alamat tujuan\n• <b>Komentar/Memo: {memo}</b>\n• Status berhasil\n\n⚠️ <b>Pastikan komentar terlihat di screenshot!</b>\n\n⏳ <i>Menunggu bukti transfer...</i>",
    
    'proof_received': "✅ <b>Bukti Diterima</b>\n\n💎 <b>TON:</b> {ton_amount}\n💰 <b>Anda terima:</b> Rp {total:,.0f}\n💳 <b>Metode:</b> {payment_method}\n\n🆔 <b>Kode:</b> <code>{order_id}</code>\n\n⏰ <i>Mohon tunggu, admin akan memproses pembayaran Anda.</i>" + COPYRIGHT_TEXT,
    
    'order_cancelled': "❌ <i>Transaksi dibatalkan</i>" + COPYRIGHT_TEXT,
    
    'invalid_number': "❌ <i>Mohon masukkan angka yang valid</i>\n\nContoh: 5",
    
    'invalid_amount': "❌ <i>Jumlah minimum {min_ton} TON</i>",
    
    'invalid_max_amount': "❌ <i>Maksimal {max_ton} TON (≈ Rp {max_idr:,.0f})</i>\n\n💡 <i>Batas maksimal transaksi: Rp 1.000.000</i>",
    
    'help_text': "ℹ️ <b>Informasi Bot</b>\n\n💰 <b>Harga Jual TON:</b> Rp {price:,.0f}/TON\n🔴 <b>Maksimal Transaksi:</b> Rp 1.000.000\n─────────────\n💳 <b>Tersedia Metode pembayaran:</b>\n• BCA\n• BRI\n• BNI\n• Mandiri\n• SeaBank\n• Dana\n• GoPay\n• OVO\n• ShopeePay\n─────────────\n📝 <b>Cara jual TON:</b>\n1. Atur metode pembayaran\n2. Klik Jual TON\n3. Masukkan jumlah\n4. Kirim TON ke wallet\n5. Upload bukti\n6. Terima Rupiah" + COPYRIGHT_TEXT,
    
    'admin_notification': "🔔 <b>TRANSAKSI BARU!</b>\n\n👤 <b>Penjual:</b>\n{user_info}\n🆔 <b>ID:</b> <code>{user_id}</code>\n\n💎 <b>Detail Transaksi:</b>\n💎 <b>Jumlah TON:</b> {ton_amount}\n💬 <b>Memo/Comment:</b> <code>{memo}</code>\n💰 <b>Transfer ke user:</b> Rp {total:,.0f}\n\n💳 <b>Kirim ke:</b>\n{payment_info}\n\n📸 <b>Bukti Transfer TON:</b>\n<i>(Lihat foto di bawah)</i>\n\n🆔 <b>Kode:</b> <code>{order_id}</code>\n\n<b>Untuk konfirmasi setelah transfer:</b>\n<code>selesai {order_id}</code>",
    
    'admin_confirm_success': "✅ <b>Konfirmasi Berhasil</b>\n\n<i>Notifikasi terkirim ke:</i>\n{user_mention}\n💰 Transfer: Rp {total:,.0f}",
    
    'user_payment_received': "✅ <b>Pembayaran Diterima!</b>\n\n💰 Transfer <b>Rp {total:,.0f}</b> telah masuk ke rekening Anda dari penjualan <b>{ton_amount} TON</b>.\n\n✨ <i>Terima kasih telah menggunakan layanan kami.</i>\n\n📢 Berikan testimoni: https://t.me/{channel}" + COPYRIGHT_TEXT,
    
    'admin_only': "⚠️ <i>Fitur ini hanya untuk admin</i>",
    
    'invalid_format': "❌ <b>Format salah</b>\n\n<i>Gunakan:</i> <code>selesai ORD-12345678</code>",
    
    'order_not_found': "❌ <i>Kode transaksi tidak ditemukan</i>",
    
    'owner_only': "⚠️ <i>Fitur ini hanya untuk pemilik</i>",
    
    'stats_menu': "📊 <b>Statistik Bot</b>\n\n👥 <b>Total pengguna:</b> {total_users}\n💰 <b>Harga TON:</b> Rp {price:,.0f}\n✅ <b>Transaksi selesai:</b> {completed_trans}\n⏳ <b>Transaksi pending:</b> {pending_trans}\n\n<i>Diperbarui: {update_time}</i>",
    
    'public_stats': "📊 <b>Statistik</b>\n\n👥 <b>Pengguna:</b> {total_users}\n💰 <b>Harga:</b> Rp {price:,.0f}/TON\n✅ <b>Transaksi:</b> {completed_trans}\n\n<i>Diperbarui: {update_time}</i>" + COPYRIGHT_TEXT,
    
    'confirm_payment_info': "✅ <b>Konfirmasi Data Pembayaran</b>\n\n💳 <b>Metode:</b> {method}\n👤 <b>Nama:</b> {name}\n🔢 <b>Nomor:</b> <code>{number}</code>\n\n<i>Apakah data sudah benar?</i>",
    
    'price_update_failed': "⚠️ <i>Gagal mengambil harga TON. Coba lagi nanti.</i>",
    
    'please_send_text': "❌ <i>Mohon kirim pesan teks, bukan {type}</i>",
    
    'please_send_photo': "❌ <i>Mohon kirim foto bukti transfer</i>",
    
    'no_transactions': "📜 <b>Riwayat Transaksi</b>\n\n<i>Anda belum memiliki transaksi.</i>" + COPYRIGHT_TEXT,
    
    # ============================================================
    # REFERRAL SYSTEM TEXTS
    # ============================================================
    'referral_balance': "💰 <b>Saldo Rujukan Anda</b>\n\n💵 <b>Total Penghasilan:</b> Rp {balance:,.0f}\n👥 <b>Jumlah Rujukan Sukses:</b> {total_referrals} orang\n\n🔗 <b>Link Rujukan Anda:</b>\n<code>https://t.me/{bot_username}?start=ref_{user_id}</code>\n\n💡 <i>Bagikan link di atas dan dapatkan 0.3% dari setiap transaksi orang yang bergabung melalui link Anda!</i>" + COPYRIGHT_TEXT,
    
    'referral_welcome': "🎉 <b>Selamat!</b>\n\nAnda bergabung melalui rujukan dari pengguna lain. Selamat menggunakan layanan kami!" + COPYRIGHT_TEXT,
    
    'referral_new_user': "🎊 <b>Rujukan Baru!</b>\n\n👤 <b>{referred_name}</b> bergabung melalui link rujukan Anda!\n\n💡 <i>Anda akan mendapat 0.3% dari setiap transaksi mereka.</i>",
    
    'referral_earning_notification': "💰 <b>Penghasilan Rujukan!</b>\n\n💵 <b>+Rp {amount:,.0f}</b>\n\nAnda mendapat komisi dari transaksi rujukan Anda.\n\n📊 <b>Saldo rujukan saat ini:</b> Rp {new_balance:,.0f}",
    
    'withdrawal_request_sent': "✅ <b>Permintaan Penarikan Terkirim</b>\n\n💵 <b>Jumlah:</b> Rp {amount:,.0f}\n💳 <b>Metode:</b> {payment_method}\n👤 <b>Nama:</b> {account_name}\n🔢 <b>Nomor:</b> <code>{account_number}</code>\n\n⏳ <i>Mohon tunggu, admin akan memproses penarikan Anda.</i>" + COPYRIGHT_TEXT,
    
    'withdrawal_insufficient': "❌ <b>Saldo Tidak Cukup</b>\n\n💵 <b>Saldo Anda:</b> Rp {balance:,.0f}\n📊 <b>Minimal Penarikan:</b> Rp {min_amount:,.0f}\n\n<i>Kumpulkan lebih banyak rujukan untuk mencapai batas minimal penarikan!</i>" + COPYRIGHT_TEXT,
    
    'withdrawal_confirm': "💳 <b>Konfirmasi Penarikan</b>\n\n💵 <b>Jumlah:</b> Rp {amount:,.0f}\n💳 <b>Metode:</b> {payment_method}\n👤 <b>Nama:</b> {account_name}\n🔢 <b>Nomor:</b> <code>{account_number}</code>\n\n<i>Apakah data sudah benar?</i>",
    
    'withdrawal_admin_notification': "🔔 <b>PERMINTAAN PENARIKAN!</b>\n\n👤 <b>User:</b> {user_info}\n🆔 <b>ID:</b> <code>{user_id}</code>\n\n💵 <b>Jumlah:</b> Rp {amount:,.0f}\n💳 <b>Metode:</b> {payment_method}\n👤 <b>Nama:</b> {account_name}\n🔢 <b>Nomor:</b> <code>{account_number}</code>\n\n🆔 <b>Request ID:</b> <code>WD-{request_id}</code>\n\n<b>Untuk konfirmasi setelah transfer:</b>\n<code>bayarwd WD-{request_id}</code>",
    
    'no_payment_method_withdrawal': "⚠️ <b>Metode Pembayaran Belum Diatur</b>\n\n<i>Silakan atur metode pembayaran terlebih dahulu sebelum melakukan penarikan.</i>" + COPYRIGHT_TEXT,
    
    'withdrawal_completed': "✅ <b>Penarikan Berhasil!</b>\n\n💵 <b>Jumlah:</b> Rp {amount:,.0f}\n💳 <b>Metode:</b> {payment_method}\n👤 <b>Nama:</b> {account_name}\n🔢 <b>Nomor:</b> <code>{account_number}</code>\n\n✨ <i>Dana telah ditransfer ke rekening Anda.</i>" + COPYRIGHT_TEXT,
    
    'admin_withdrawal_confirm_success': "✅ <b>Penarikan Dikonfirmasi</b>\n\n<i>Notifikasi terkirim ke:</i>\n{user_mention}\n💰 Transfer: Rp {amount:,.0f}",
    
    'withdrawal_not_found': "❌ <i>Permintaan penarikan tidak ditemukan</i>",
    
    'withdrawal_invalid_format': "❌ <b>Format salah</b>\n\n<i>Gunakan:</i> <code>bayarwd WD-12345</code>",
    
    # ============================================================
    # BROADCAST SYSTEM TEXTS
    # ============================================================
    'broadcast_admin_only': "⚠️ <i>Perintah /broadcast hanya untuk admin.</i>",
    
    'broadcast_usage': "📢 <b>Cara Penggunaan Broadcast</b>\n\n"
                       "<b>Format:</b>\n"
                       "<code>/broadcast [pesan]</code>\n\n"
                       "<b>Contoh:</b>\n"
                       "<code>/broadcast 🎉 Update Baru! Sekarang ada fitur referral!</code>\n\n"
                       "<b>Untuk broadcast dengan gambar:</b>\n"
                       "1. Kirim gambar dengan caption yang diawali <code>/broadcast</code>\n"
                       "2. Contoh caption: <code>/broadcast 🔥 Promo Spesial!</code>\n\n"
                       "💡 <i>Pesan akan dikirim ke semua pengguna bot.</i>",
    
    'broadcast_started': "📢 <b>Broadcast Dimulai</b>\n\n"
                         "📝 <b>Pesan:</b>\n{message}\n\n"
                         "👥 <b>Total User:</b> {total_users}\n"
                         "⏳ <i>Sedang mengirim...</i>",
    
    'broadcast_completed': "✅ <b>Broadcast Selesai</b>\n\n"
                           "📝 <b>Pesan:</b>\n{message}\n\n"
                           "📊 <b>Hasil:</b>\n"
                           "👥 Total User: {total_users}\n"
                           "✅ Berhasil: {success_count}\n"
                           "❌ Gagal: {failed_count}\n\n"
                           "⏱️ <i>Waktu: {duration:.1f} detik</i>",
    
    'broadcast_no_users': "⚠️ <i>Tidak ada pengguna untuk broadcast.</i>",
    
    'broadcast_confirm': "📢 <b>Konfirmasi Broadcast</b>\n\n"
                         "📝 <b>Pesan yang akan dikirim:</b>\n"
                         "────────────────\n"
                         "{message}\n"
                         "────────────────\n\n"
                         "👥 <b>Akan dikirim ke:</b> {total_users} pengguna\n\n"
                         "⚠️ <i>Apakah Anda yakin ingin mengirim broadcast ini?</i>",
    
    'broadcast_cancelled': "❌ <i>Broadcast dibatalkan.</i>",
    
    'broadcast_with_image': "📢 <b>Broadcast dengan Gambar</b>\n\n"
                            "📝 <b>Caption:</b>\n{message}\n\n"
                            "👥 <b>Total User:</b> {total_users}\n"
                            "⏳ <i>Sedang mengirim...</i>",
}


def get_text(key: str, **kwargs) -> str:
    """Ambil teks dengan format"""
    text = TEXTS.get(key, "")
    return text.format(**kwargs) if kwargs else text
