"""
Keyboard generators untuk TukarTON bot
"""

from telegram import ReplyKeyboardMarkup, KeyboardButton


def get_main_button_keyboard():
    """Buat keyboard tombol menu utama"""
    keyboard = [
        [KeyboardButton("💎 Jual TON")],
        [KeyboardButton("📜 Riwayat"), KeyboardButton("💰 Saldo")],
        [KeyboardButton("💳 Atur Pembayaran")],
        [KeyboardButton("📊 Statistik"), KeyboardButton("ℹ️ Informasi")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
