"""
Helper functions untuk TukarTON bot
"""

import random
import string
from datetime import datetime

from ..config import PAYMENT_METHODS, MAX_TRANSACTION_IDR
from ..database import get_user


def generate_order_id() -> str:
    """Generate kode transaksi unik"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    random_str = ''.join(random.choices(string.digits, k=4))
    return f"ORD-{timestamp}{random_str}"


def get_memo_from_order_id(order_id: str) -> str:
    """Ambil 4 digit terakhir dari Order ID untuk memo"""
    return order_id[-4:]


def format_datetime(dt_string):
    """Format datetime string ke format yang lebih readable"""
    try:
        dt = datetime.strptime(dt_string, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%d/%m/%Y %H:%M")
    except:
        return dt_string


def get_payment_fee(payment_type: str, payment_method: str) -> int:
    """Dapatkan biaya admin berdasarkan metode pembayaran"""
    if payment_type == 'bank':
        return PAYMENT_METHODS['bank']['options'][payment_method]['fee']
    elif payment_type == 'ewallet':
        return PAYMENT_METHODS['ewallet']['fee']
    return 0


def calculate_max_ton(price_per_ton, payment_method_type, payment_method):
    """Hitung maksimal TON berdasarkan batas Rp. 1.000.000"""
    fee = get_payment_fee(payment_method_type, payment_method)
    max_ton = (MAX_TRANSACTION_IDR + fee) / price_per_ton
    return round(max_ton, 2)


def check_user_has_payment_method(user_id: int) -> bool:
    """Cek apakah pengguna sudah mengatur metode pembayaran"""
    user = get_user(user_id)
    if not user:
        return False
    
    required_fields = ['payment_method_type', 'payment_method', 'account_name', 'account_number']
    return all(user.get(field) for field in required_fields)
