"""
Fungsi untuk mengambil dan mengelola harga TON
"""

import logging
from datetime import datetime
import aiohttp

from ..config import MARGIN_PER_TON

logger = logging.getLogger(__name__)

# Cache harga TON
ton_price_cache = {
    'price_idr': 0,
    'price_usd': 0,
    'last_update': None
}


async def fetch_ton_price():
    """Ambil harga TON dari CoinGecko"""
    try:
        async with aiohttp.ClientSession() as session:
            url = "https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd"
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    price_usd = data['the-open-network']['usd']
                    
                    url_idr = "https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=idr"
                    async with session.get(url_idr) as resp_idr:
                        if resp_idr.status == 200:
                            data_idr = await resp_idr.json()
                            usd_to_idr = data_idr['tether']['idr']
                            
                            price_idr_base = price_usd * usd_to_idr
                            price_idr_buy = price_idr_base - MARGIN_PER_TON
                            
                            ton_price_cache['price_usd'] = price_usd
                            ton_price_cache['price_idr'] = price_idr_buy
                            ton_price_cache['last_update'] = datetime.now()
                            
                            logger.info(f"Harga diperbarui: ${price_usd} | Rp {price_idr_buy:,.0f}")
                            return True
        return False
    except Exception as e:
        logger.error(f"Gagal mengambil harga TON: {e}")
        return False


async def get_ton_price():
    """Dapatkan harga TON, perbarui jika perlu"""
    if ton_price_cache['last_update'] is None or \
       (datetime.now() - ton_price_cache['last_update']).seconds > 600:
        await fetch_ton_price()
    
    return ton_price_cache['price_idr']


def get_price_update_time():
    """Dapatkan waktu pembaruan harga terakhir"""
    if ton_price_cache['last_update']:
        return ton_price_cache['last_update'].strftime("%H:%M")
    return "Belum diperbarui"
