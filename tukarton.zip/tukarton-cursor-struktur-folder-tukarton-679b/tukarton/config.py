"""
Konfigurasi dan pengaturan bot TukarTON
"""

import logging

# ============================================================
# BOT CONFIGURATION
# ============================================================
TELEGRAM_BOT_TOKEN = "TELEGRAM_BOT_TOKEN_ANDA"

# ============================================================
# PRICING CONFIGURATION
# ============================================================
MARGIN_PER_TON = 1300
MIN_TON = 0.5
MAX_TRANSACTION_IDR = 1000000  # Maksimal Rp. 1.000.000 per transaksi

# ============================================================
# ADMIN CONFIGURATION
# ============================================================
ADMIN_USERNAME = "insikeX"
OWNER_USER_ID = 6683929810

# ============================================================
# WALLET CONFIGURATION
# ============================================================
YOUR_TON_WALLET = "UQCWSP7k-g_fbPrttnwV3Aahfmt5bpmXZS5bkgR2CPWqVluE"

# ============================================================
# CHANNEL CONFIGURATION
# ============================================================
TESTIMONI_CHANNEL = "tukarton"  # Username channel tanpa @ untuk link testimoni

# ============================================================
# REFERRAL SYSTEM CONFIGURATION
# ============================================================
REFERRAL_PERCENTAGE = 0.3  # 0.3% dari setiap transaksi referral
MIN_WITHDRAWAL_AMOUNT = 25000  # Minimal Rp 25.000 untuk penarikan

# ============================================================
# PAYMENT METHODS CONFIGURATION
# ============================================================
PAYMENT_METHODS = {
    'bank': {
        'name': 'Transfer Bank',
        'options': {
            'BCA': {'fee': 2500},
            'BRI': {'fee': 2500},
            'BNI': {'fee': 2500},
            'MANDIRI': {'fee': 2500},
            'SEABANK': {'fee': 0}
        }
    },
    'ewallet': {
        'name': 'E-Wallet',
        'fee': 1200,
        'options': ['DANA', 'GOPAY', 'OVO', 'SHOPEEPAY']
    }
}

# ============================================================
# DATABASE CONFIGURATION
# ============================================================
DB_FILE = 'tonbot_data.db'

# ============================================================
# BRANDING
# ============================================================
COPYRIGHT_TEXT = "\n\n<i>© 2026 Vyérru & Co.</i>"

# ============================================================
# LOGGING CONFIGURATION
# ============================================================
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)
