"""
Payment setup handlers untuk TukarTON bot
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import PAYMENT_METHODS
from ..constants import get_text
from ..database import save_user

from .state import user_payment_info

logger = logging.getLogger(__name__)


async def handle_setup_payment_method(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk pengaturan metode pembayaran"""
    text = get_text('select_payment_method')
    
    keyboard = [
        [InlineKeyboardButton("🏦 Transfer Bank", callback_data="setup_bank")],
        [InlineKeyboardButton("📱 E-Wallet", callback_data="setup_ewallet")],
        [InlineKeyboardButton("❌ Batalkan", callback_data="cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='HTML')


async def handle_setup_payment_method_inline(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk pengaturan metode pembayaran dari tombol inline"""
    text = get_text('select_payment_method')
    
    keyboard = [
        [InlineKeyboardButton("🏦 Transfer Bank", callback_data="setup_bank")],
        [InlineKeyboardButton("📱 E-Wallet", callback_data="setup_ewallet")],
        [InlineKeyboardButton("❌ Batalkan", callback_data="cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass


async def handle_setup_bank_selection(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk menampilkan pilihan bank"""
    text = get_text('select_bank')
    
    keyboard = []
    for bank_name, bank_info in PAYMENT_METHODS['bank']['options'].items():
        fee_text = f"Gratis" if bank_info['fee'] == 0 else f"Rp {bank_info['fee']:,}"
        keyboard.append([InlineKeyboardButton(
            f"🏦 {bank_name} ({fee_text})", 
            callback_data=f"setup_bank_{bank_name}"
        )])
    keyboard.append([InlineKeyboardButton("🔙 Kembali", callback_data="setup_payment_method")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass


async def handle_setup_ewallet_selection(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk menampilkan pilihan e-wallet"""
    text = get_text('select_ewallet')
    
    keyboard = []
    for ewallet in PAYMENT_METHODS['ewallet']['options']:
        keyboard.append([InlineKeyboardButton(f"📱 {ewallet}", callback_data=f"setup_ewallet_{ewallet}")])
    keyboard.append([InlineKeyboardButton("🔙 Kembali", callback_data="setup_payment_method")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass


async def handle_setup_bank_selected(query, context: ContextTypes.DEFAULT_TYPE, bank_name: str):
    """Handler ketika bank dipilih"""
    user_id = query.from_user.id
    
    if user_id not in user_payment_info:
        user_payment_info[user_id] = {}
    
    user_payment_info[user_id]['setup_method_type'] = 'bank'
    user_payment_info[user_id]['setup_method'] = bank_name
    
    text = get_text('input_account_name', method=bank_name)
    
    try:
        await query.message.edit_text(text, parse_mode='HTML')
    except:
        pass
    
    context.user_data['payment_step'] = 'setup_awaiting_name'


async def handle_setup_ewallet_selected(query, context: ContextTypes.DEFAULT_TYPE, ewallet_name: str):
    """Handler ketika e-wallet dipilih"""
    user_id = query.from_user.id
    
    if user_id not in user_payment_info:
        user_payment_info[user_id] = {}
    
    user_payment_info[user_id]['setup_method_type'] = 'ewallet'
    user_payment_info[user_id]['setup_method'] = ewallet_name
    
    text = get_text('input_account_name', method=ewallet_name)
    
    try:
        await query.message.edit_text(text, parse_mode='HTML')
    except:
        pass
    
    context.user_data['payment_step'] = 'setup_awaiting_name'


async def handle_confirm_setup_payment_data(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk konfirmasi setup data pembayaran"""
    user_id = query.from_user.id
    
    if user_id not in user_payment_info:
        await query.message.edit_text("❌ <i>Sesi berakhir.</i>", parse_mode='HTML')
        return
    
    payment_data = user_payment_info[user_id]
    
    save_user(user_id, query.from_user.username, query.from_user.first_name, {
        'payment_method_type': payment_data['setup_method_type'],
        'payment_method': payment_data['setup_method'],
        'account_name': payment_data['setup_account_name'],
        'account_number': payment_data['setup_account_number']
    })
    
    text = get_text('payment_method_saved',
                   method=payment_data['setup_method'],
                   name=payment_data['setup_account_name'],
                   number=payment_data['setup_account_number'])
    
    keyboard = [[InlineKeyboardButton("💎 Jual TON", callback_data="start_sell_ton")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass
    
    del user_payment_info[user_id]
    context.user_data['payment_step'] = None
    
    logger.info(f"User {user_id} setup payment method: {payment_data['setup_method']}")
