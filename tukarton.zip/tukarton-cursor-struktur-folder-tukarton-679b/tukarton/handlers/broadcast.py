"""
Broadcast handlers untuk TukarTON bot
"""

import logging
import asyncio
import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import OWNER_USER_ID
from ..constants import get_text
from ..database import get_all_user_ids, save_broadcast_log

logger = logging.getLogger(__name__)


async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk perintah /broadcast - khusus admin/owner
    
    Note: Untuk broadcast dengan gambar, gunakan caption yang dimulai dengan /broadcast
    CommandHandler hanya menangani pesan teks, bukan foto
    """
    user_id = update.effective_user.id
    
    # Validasi hanya owner yang bisa broadcast
    if user_id != OWNER_USER_ID:
        await update.message.reply_text(get_text('broadcast_admin_only'), parse_mode='HTML')
        return
    
    # Cek apakah ada pesan untuk broadcast
    if not context.args or len(context.args) == 0:
        await update.message.reply_text(get_text('broadcast_usage'), parse_mode='HTML')
        return
    
    # Gabungkan argumen menjadi pesan
    broadcast_message = ' '.join(context.args)
    
    # Tampilkan konfirmasi
    await show_broadcast_confirmation(update, context, broadcast_message)


async def show_broadcast_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE, message: str, photo_file_id: str = None):
    """Tampilkan konfirmasi sebelum broadcast"""
    user_ids = get_all_user_ids()
    total_users = len(user_ids)
    
    if total_users == 0:
        await update.message.reply_text(get_text('broadcast_no_users'), parse_mode='HTML')
        return
    
    # Simpan data broadcast sementara
    context.user_data['broadcast_pending'] = {
        'message': message,
        'photo_file_id': photo_file_id,
        'total_users': total_users
    }
    
    confirm_text = get_text('broadcast_confirm', 
                           message=message[:500] + ('...' if len(message) > 500 else ''),
                           total_users=total_users)
    
    keyboard = [
        [InlineKeyboardButton("✅ Ya, Kirim Broadcast", callback_data="confirm_broadcast_yes")],
        [InlineKeyboardButton("❌ Batalkan", callback_data="confirm_broadcast_no")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if photo_file_id:
        await update.message.reply_photo(
            photo=photo_file_id,
            caption=confirm_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
    else:
        await update.message.reply_text(confirm_text, reply_markup=reply_markup, parse_mode='HTML')


async def handle_broadcast_with_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk broadcast dengan gambar"""
    user_id = update.effective_user.id
    
    if user_id != OWNER_USER_ID:
        await update.message.reply_text(get_text('broadcast_admin_only'), parse_mode='HTML')
        return
    
    caption = update.message.caption or ""
    
    # Hapus /broadcast dari caption
    if caption.startswith('/broadcast'):
        caption = caption[len('/broadcast'):].strip()
    
    if not caption:
        await update.message.reply_text(
            "❌ <i>Silakan tambahkan caption untuk broadcast dengan gambar.</i>\n\n"
            "<b>Contoh:</b> Kirim gambar dengan caption:\n"
            "<code>/broadcast 🎉 Promo Spesial Hari Ini!</code>",
            parse_mode='HTML'
        )
        return
    
    # Ambil file_id gambar (ukuran terbesar)
    photo_file_id = update.message.photo[-1].file_id
    
    # Tampilkan konfirmasi
    await show_broadcast_confirmation(update, context, caption, photo_file_id)


async def execute_broadcast(query, context: ContextTypes.DEFAULT_TYPE):
    """Eksekusi broadcast ke semua user"""
    broadcast_data = context.user_data.get('broadcast_pending')
    
    if not broadcast_data:
        try:
            await query.message.edit_text("❌ <i>Sesi broadcast berakhir. Silakan coba lagi.</i>", parse_mode='HTML')
        except:
            pass
        return
    
    message = broadcast_data['message']
    photo_file_id = broadcast_data.get('photo_file_id')
    total_users = broadcast_data['total_users']
    
    # Ambil semua user_id
    user_ids = get_all_user_ids()
    
    if len(user_ids) == 0:
        try:
            await query.message.edit_text(get_text('broadcast_no_users'), parse_mode='HTML')
        except:
            pass
        return
    
    # Update pesan dengan status "sedang mengirim"
    if photo_file_id:
        started_text = get_text('broadcast_with_image', message=message[:200] + ('...' if len(message) > 200 else ''), total_users=total_users)
    else:
        started_text = get_text('broadcast_started', message=message[:200] + ('...' if len(message) > 200 else ''), total_users=total_users)
    
    try:
        await query.message.edit_text(started_text, parse_mode='HTML')
    except:
        pass
    
    # Mulai broadcast
    start_time = time.time()
    success_count = 0
    failed_count = 0
    
    # Format pesan broadcast dengan header
    broadcast_content = f"📢 <b>PENGUMUMAN</b>\n\n{message}\n\n<i>— Tim @tukartonbot</i>"
    
    for target_user_id in user_ids:
        try:
            if photo_file_id:
                # Kirim dengan gambar
                await context.bot.send_photo(
                    chat_id=target_user_id,
                    photo=photo_file_id,
                    caption=broadcast_content,
                    parse_mode='HTML'
                )
            else:
                # Kirim teks saja
                await context.bot.send_message(
                    chat_id=target_user_id,
                    text=broadcast_content,
                    parse_mode='HTML'
                )
            success_count += 1
            
            # Delay untuk menghindari rate limit Telegram
            await asyncio.sleep(0.05)  # 50ms delay antara setiap pesan
            
        except Exception as e:
            failed_count += 1
            logger.warning(f"Failed to send broadcast to user {target_user_id}: {e}")
    
    end_time = time.time()
    duration = end_time - start_time
    
    # Simpan log broadcast
    admin_id = query.from_user.id
    save_broadcast_log(admin_id, message, len(user_ids), success_count, failed_count)
    
    # Update pesan dengan hasil
    completed_text = get_text('broadcast_completed',
                             message=message[:200] + ('...' if len(message) > 200 else ''),
                             total_users=len(user_ids),
                             success_count=success_count,
                             failed_count=failed_count,
                             duration=duration)
    
    try:
        await query.message.edit_text(completed_text, parse_mode='HTML')
    except:
        pass
    
    # Bersihkan data sementara
    context.user_data['broadcast_pending'] = None
    
    logger.info(f"Broadcast completed: {success_count}/{len(user_ids)} sent, {failed_count} failed, duration: {duration:.1f}s")


async def handle_broadcast_callback(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler callback untuk konfirmasi broadcast"""
    user_id = query.from_user.id
    
    # Validasi hanya owner
    if user_id != OWNER_USER_ID:
        await query.answer("⚠️ Hanya admin yang bisa melakukan broadcast", show_alert=True)
        return
    
    if query.data == "confirm_broadcast_yes":
        await query.answer("📢 Memulai broadcast...")
        await execute_broadcast(query, context)
    
    elif query.data == "confirm_broadcast_no":
        await query.answer("❌ Broadcast dibatalkan")
        context.user_data['broadcast_pending'] = None
        try:
            await query.message.edit_text(get_text('broadcast_cancelled'), parse_mode='HTML')
        except:
            pass
