"""
Command handlers untuk TukarTON bot
/start, /help commands
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes

from ..config import ADMIN_USERNAME, COPYRIGHT_TEXT
from ..constants import get_text
from ..database import save_user, save_referral
from ..utils import fetch_ton_price, get_ton_price, get_main_button_keyboard

logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk perintah /start"""
    user = update.effective_user
    user_id = user.id
    
    save_user(user_id, user.username, user.first_name)
    
    if user.username:
        user_greeting = f"@{user.username}"
    else:
        user_greeting = user.first_name
    
    await fetch_ton_price()
    
    # Cek apakah ada parameter referral
    if context.args and len(context.args) > 0:
        referral_param = context.args[0]
        
        # Format: ref_USERID
        if referral_param.startswith('ref_'):
            try:
                referrer_id = int(referral_param.replace('ref_', ''))
                
                # Simpan referral jika belum pernah direferensikan
                if save_referral(referrer_id, user_id):
                    # Notifikasi ke user yang bergabung
                    await update.message.reply_text(
                        get_text('referral_welcome'),
                        parse_mode='HTML'
                    )
                    
                    # Notifikasi ke referrer
                    referred_name = user.first_name
                    if user.username:
                        referred_name += f" (@{user.username})"
                    
                    try:
                        await context.bot.send_message(
                            chat_id=referrer_id,
                            text=get_text('referral_new_user', referred_name=referred_name),
                            parse_mode='HTML'
                        )
                    except Exception as e:
                        logger.error(f"Failed to notify referrer {referrer_id}: {e}")
                    
                    logger.info(f"New referral: {referrer_id} -> {user_id}")
            except ValueError:
                pass  # Invalid referral parameter
    
    welcome_text = get_text('welcome', user_greeting=user_greeting)
    context.user_data.clear()
    
    await update.message.reply_text(
        welcome_text, 
        reply_markup=get_main_button_keyboard(),
        parse_mode='HTML'
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk perintah /help"""
    price = await get_ton_price()
    
    help_text = (
        "📖 <b>PANDUAN PENGGUNAAN BOT</b>\n\n"
        "🔹 <b>Cara Jual TON:</b>\n"
        "1️⃣ Klik <b>💳 Atur Pembayaran</b> untuk setup rekening\n"
        "2️⃣ Klik <b>💎 Jual TON</b> untuk memulai\n"
        "3️⃣ Masukkan jumlah TON yang ingin dijual\n"
        "4️⃣ Kirim TON ke alamat yang diberikan\n"
        "5️⃣ Upload bukti transfer\n"
        "6️⃣ Tunggu admin memproses pembayaran\n\n"
        "🔹 <b>Menu Tersedia:</b>\n"
        "• 💎 <b>Jual TON</b> - Jual Toncoin Anda\n"
        "• 💳 <b>Atur Pembayaran</b> - Setup metode pembayaran\n"
        "• 📜 <b>Riwayat</b> - Lihat riwayat transaksi\n"
        "• 💰 <b>Saldo</b> - Cek saldo rujukan\n"
        "• 📊 <b>Statistik</b> - Lihat statistik bot\n"
        "• ℹ️ <b>Informasi</b> - Info harga dan metode pembayaran\n\n"
        "🔹 <b>Sistem Rujukan:</b>\n"
        "• Bagikan link rujukan Anda\n"
        "• Dapatkan 0.3% dari setiap transaksi rujukan\n"
        "• Tarik saldo saat mencapai Rp 25.000\n\n"
        f"💰 <b>Harga saat ini:</b> Rp {price:,.0f}/TON\n\n"
        "📞 <b>Bantuan:</b> @" + ADMIN_USERNAME
        + COPYRIGHT_TEXT
    )
    
    await update.message.reply_text(
        help_text,
        reply_markup=get_main_button_keyboard(),
        parse_mode='HTML'
    )
