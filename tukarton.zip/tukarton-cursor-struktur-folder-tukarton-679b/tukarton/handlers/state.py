"""
Shared state untuk handlers
"""

# Pending orders storage
pending_orders = {}

# User payment info storage  
user_payment_info = {}
