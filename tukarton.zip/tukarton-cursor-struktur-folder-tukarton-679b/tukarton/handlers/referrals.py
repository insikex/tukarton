"""
Referral system handlers untuk TukarTON bot
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import MIN_WITHDRAWAL_AMOUNT, OWNER_USER_ID
from ..constants import get_text
from ..database import (
    get_user,
    get_referral_stats,
    deduct_referral_balance,
    save_withdrawal_request,
    add_referral_earning
)

logger = logging.getLogger(__name__)


async def handle_referral_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk menampilkan saldo rujukan"""
    user_id = update.effective_user.id
    bot_username = (await context.bot.get_me()).username
    
    # Dapatkan statistik referral
    referral_stats = get_referral_stats(user_id)
    balance = referral_stats['referral_balance']
    total_referrals = referral_stats['total_referrals']
    
    balance_text = get_text('referral_balance',
                           balance=balance,
                           total_referrals=total_referrals,
                           bot_username=bot_username,
                           user_id=user_id)
    
    # Buat tombol Penarikan
    keyboard = []
    
    if balance >= MIN_WITHDRAWAL_AMOUNT:
        # Tombol aktif jika saldo >= 25.000
        keyboard.append([InlineKeyboardButton("💸 Penarikan", callback_data="withdrawal_request")])
    else:
        # Tombol nonaktif dengan pesan
        keyboard.append([InlineKeyboardButton(f"💸 Penarikan (Min. Rp {MIN_WITHDRAWAL_AMOUNT:,.0f})", callback_data="withdrawal_insufficient")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(balance_text, reply_markup=reply_markup, parse_mode='HTML')


async def handle_withdrawal_request(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk permintaan penarikan"""
    user_id = query.from_user.id
    
    # Cek saldo
    referral_stats = get_referral_stats(user_id)
    balance = referral_stats['referral_balance']
    
    if balance < MIN_WITHDRAWAL_AMOUNT:
        insufficient_text = get_text('withdrawal_insufficient',
                                    balance=balance,
                                    min_amount=MIN_WITHDRAWAL_AMOUNT)
        try:
            await query.message.edit_text(insufficient_text, parse_mode='HTML')
        except:
            pass
        return
    
    # Cek apakah user sudah punya metode pembayaran
    user_info = get_user(user_id)
    
    if not user_info or not user_info.get('payment_method'):
        no_payment_text = get_text('no_payment_method_withdrawal')
        keyboard = [[InlineKeyboardButton("💳 Atur Pembayaran", callback_data="setup_payment_method")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        try:
            await query.message.edit_text(no_payment_text, reply_markup=reply_markup, parse_mode='HTML')
        except:
            pass
        return
    
    # Tampilkan konfirmasi penarikan
    confirm_text = get_text('withdrawal_confirm',
                           amount=balance,
                           payment_method=user_info['payment_method'],
                           account_name=user_info['account_name'],
                           account_number=user_info['account_number'])
    
    keyboard = [
        [InlineKeyboardButton("✅ Ya, Tarik Saldo", callback_data="confirm_withdrawal_yes")],
        [InlineKeyboardButton("❌ Batalkan", callback_data="confirm_withdrawal_no")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Simpan data penarikan sementara
    context.user_data['withdrawal_pending'] = {
        'amount': balance,
        'payment_method': user_info['payment_method'],
        'account_name': user_info['account_name'],
        'account_number': user_info['account_number']
    }
    
    try:
        await query.message.edit_text(confirm_text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass


async def handle_confirm_withdrawal(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk konfirmasi penarikan"""
    user_id = query.from_user.id
    user = query.from_user
    
    withdrawal_data = context.user_data.get('withdrawal_pending')
    
    if not withdrawal_data:
        await query.message.edit_text("❌ <i>Sesi berakhir. Silakan coba lagi.</i>", parse_mode='HTML')
        return
    
    amount = withdrawal_data['amount']
    payment_method = withdrawal_data['payment_method']
    account_name = withdrawal_data['account_name']
    account_number = withdrawal_data['account_number']
    
    # Kurangi saldo
    if not deduct_referral_balance(user_id, amount):
        await query.message.edit_text("❌ <i>Gagal memproses penarikan. Saldo tidak mencukupi.</i>", parse_mode='HTML')
        return
    
    # Simpan permintaan penarikan
    request_id = save_withdrawal_request(user_id, amount, payment_method, account_name, account_number)
    
    if not request_id:
        # Kembalikan saldo jika gagal
        add_referral_earning(user_id, amount)
        await query.message.edit_text("❌ <i>Gagal menyimpan permintaan penarikan.</i>", parse_mode='HTML')
        return
    
    # Notifikasi ke user
    success_text = get_text('withdrawal_request_sent',
                           amount=amount,
                           payment_method=payment_method,
                           account_name=account_name,
                           account_number=account_number)
    
    try:
        await query.message.edit_text(success_text, parse_mode='HTML')
    except:
        pass
    
    # Notifikasi ke admin/owner
    user_info = f"{user.first_name}"
    if user.username:
        user_info += f" (@{user.username})"
    
    admin_text = get_text('withdrawal_admin_notification',
                         user_info=user_info,
                         user_id=user_id,
                         amount=amount,
                         payment_method=payment_method,
                         account_name=account_name,
                         account_number=account_number,
                         request_id=request_id)
    
    try:
        await context.bot.send_message(
            chat_id=OWNER_USER_ID,
            text=admin_text,
            parse_mode='HTML'
        )
    except Exception as e:
        logger.error(f"Failed to notify admin about withdrawal: {e}")
    
    # Bersihkan data sementara
    context.user_data['withdrawal_pending'] = None
    
    logger.info(f"Withdrawal request created: user {user_id}, amount {amount}, request_id {request_id}")
