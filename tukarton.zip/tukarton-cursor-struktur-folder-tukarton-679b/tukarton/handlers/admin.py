"""
Admin/Owner handlers untuk TukarTON bot
"""

import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import OWNER_USER_ID, REFERRAL_PERCENTAGE, TESTIMONI_CHANNEL
from ..constants import get_text
from ..database import (
    get_transaction,
    get_statistics,
    complete_transaction,
    get_referrer,
    get_referral_stats,
    get_withdrawal_request,
    complete_withdrawal_request
)
from ..utils import fetch_ton_price, get_ton_price

logger = logging.getLogger(__name__)


async def handle_public_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk statistik publik"""
    price = await get_ton_price()
    stats = get_statistics()
    update_time = datetime.now().strftime("%d/%m/%Y %H:%M")
    
    stats_text = get_text('public_stats',
                         total_users=stats['total_users'],
                         price=price,
                         completed_trans=stats['completed_transactions'],
                         update_time=update_time)
    
    await update.message.reply_text(stats_text, parse_mode='HTML')


async def handle_owner_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk owner melihat statistik bot"""
    user_id = update.effective_user.id
    
    if user_id != OWNER_USER_ID:
        await update.message.reply_text(get_text('owner_only'), parse_mode='HTML')
        return
    
    price = await get_ton_price()
    stats = get_statistics()
    update_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    stats_text = get_text('stats_menu',
                         total_users=stats['total_users'],
                         price=price,
                         completed_trans=stats['completed_transactions'],
                         pending_trans=stats['pending_transactions'],
                         update_time=update_time)
    
    keyboard = [
        [InlineKeyboardButton("🔄 Refresh", callback_data="refresh_stats")],
        [InlineKeyboardButton("❌ Tutup", callback_data="cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(stats_text, reply_markup=reply_markup, parse_mode='HTML')


async def handle_owner_stats_refresh(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk refresh statistik"""
    await fetch_ton_price()
    price = await get_ton_price()
    stats = get_statistics()
    update_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    stats_text = get_text('stats_menu',
                         total_users=stats['total_users'],
                         price=price,
                         completed_trans=stats['completed_transactions'],
                         pending_trans=stats['pending_transactions'],
                         update_time=update_time)
    
    keyboard = [
        [InlineKeyboardButton("🔄 Refresh", callback_data="refresh_stats")],
        [InlineKeyboardButton("❌ Tutup", callback_data="cancel")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(stats_text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass


async def handle_admin_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk owner konfirmasi transaksi selesai"""
    user_id = update.effective_user.id
    
    if user_id != OWNER_USER_ID:
        return
    
    text = update.message.text.strip()
    
    if not text.lower().startswith('selesai '):
        return
    
    parts = text.split(' ', 1)
    if len(parts) != 2:
        await update.message.reply_text(get_text('invalid_format'), parse_mode='HTML')
        return
    
    order_id = parts[1].strip()
    
    transaction = get_transaction(order_id)
    
    if not transaction:
        await update.message.reply_text(get_text('order_not_found'), parse_mode='HTML')
        return
    
    target_user_id = transaction['user_id']
    ton_amount = transaction['ton_amount']
    total = transaction['total']
    first_name = transaction['first_name']
    username = transaction.get('username')
    
    user_notification = get_text('user_payment_received',
                                 ton_amount=ton_amount,
                                 total=total,
                                 channel=TESTIMONI_CHANNEL)
    
    try:
        await context.bot.send_message(
            chat_id=target_user_id,
            text=user_notification,
            parse_mode='HTML'
        )
        
        user_mention = f"@{username}" if username else f"{first_name} (ID: {target_user_id})"
        admin_response = get_text('admin_confirm_success',
                                 user_mention=user_mention,
                                 total=total)
        
        await update.message.reply_text(admin_response, parse_mode='HTML')
        
        logger.info(f"Transaksi {order_id} selesai untuk user {target_user_id}")
        
        complete_transaction(order_id)
        
        # Cek apakah user yang bertransaksi memiliki referrer
        referrer_id = get_referrer(target_user_id)
        if referrer_id:
            # Hitung penghasilan referral
            referral_earning = total * (REFERRAL_PERCENTAGE / 100)
            
            # Dapatkan saldo baru referrer
            referrer_stats = get_referral_stats(referrer_id)
            new_balance = referrer_stats['referral_balance']
            
            # Kirim notifikasi ke referrer
            try:
                referral_notif = get_text('referral_earning_notification',
                                         amount=referral_earning,
                                         new_balance=new_balance)
                await context.bot.send_message(
                    chat_id=referrer_id,
                    text=referral_notif,
                    parse_mode='HTML'
                )
                logger.info(f"Referral earning notification sent to {referrer_id}: Rp {referral_earning:,.0f}")
            except Exception as e:
                logger.error(f"Failed to notify referrer {referrer_id}: {e}")
        
    except Exception as e:
        logger.error(f"Gagal kirim konfirmasi ke user {target_user_id}: {e}")
        await update.message.reply_text(
            f"❌ <i>Gagal mengirim notifikasi ke user!</i>\n<code>Error: {str(e)}</code>",
            parse_mode='HTML'
        )


async def handle_admin_withdrawal_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk admin konfirmasi penarikan selesai"""
    user_id = update.effective_user.id
    
    if user_id != OWNER_USER_ID:
        return
    
    text = update.message.text.strip()
    
    if not text.lower().startswith('bayarwd '):
        return
    
    parts = text.split(' ', 1)
    if len(parts) != 2:
        await update.message.reply_text(get_text('withdrawal_invalid_format'), parse_mode='HTML')
        return
    
    request_id_str = parts[1].strip()
    
    # Parse request_id dari format WD-12345
    if request_id_str.upper().startswith('WD-'):
        try:
            request_id = int(request_id_str[3:])
        except ValueError:
            await update.message.reply_text(get_text('withdrawal_invalid_format'), parse_mode='HTML')
            return
    else:
        try:
            request_id = int(request_id_str)
        except ValueError:
            await update.message.reply_text(get_text('withdrawal_invalid_format'), parse_mode='HTML')
            return
    
    # Ambil data withdrawal request
    withdrawal = get_withdrawal_request(request_id)
    
    if not withdrawal:
        await update.message.reply_text(get_text('withdrawal_not_found'), parse_mode='HTML')
        return
    
    if withdrawal['status'] == 'completed':
        await update.message.reply_text("⚠️ <i>Penarikan ini sudah dikonfirmasi sebelumnya.</i>", parse_mode='HTML')
        return
    
    target_user_id = withdrawal['user_id']
    amount = withdrawal['amount']
    payment_method = withdrawal['payment_method']
    account_name = withdrawal['account_name']
    account_number = withdrawal['account_number']
    first_name = withdrawal['first_name']
    username = withdrawal.get('username')
    
    # Tandai withdrawal sebagai selesai
    if not complete_withdrawal_request(request_id):
        await update.message.reply_text("❌ <i>Gagal mengupdate status penarikan.</i>", parse_mode='HTML')
        return
    
    # Kirim notifikasi ke user
    user_notification = get_text('withdrawal_completed',
                                 amount=amount,
                                 payment_method=payment_method,
                                 account_name=account_name,
                                 account_number=account_number)
    
    try:
        await context.bot.send_message(
            chat_id=target_user_id,
            text=user_notification,
            parse_mode='HTML'
        )
        
        user_mention = f"@{username}" if username else f"{first_name} (ID: {target_user_id})"
        admin_response = get_text('admin_withdrawal_confirm_success',
                                 user_mention=user_mention,
                                 amount=amount)
        
        await update.message.reply_text(admin_response, parse_mode='HTML')
        
        logger.info(f"Withdrawal WD-{request_id} completed for user {target_user_id}, amount Rp {amount:,.0f}")
        
    except Exception as e:
        logger.error(f"Gagal kirim konfirmasi penarikan ke user {target_user_id}: {e}")
        await update.message.reply_text(
            f"❌ <i>Gagal mengirim notifikasi ke user!</i>\n<code>Error: {str(e)}</code>",
            parse_mode='HTML'
        )
