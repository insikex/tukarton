"""
Handler module untuk TukarTON bot
Mengelola semua handler Telegram
"""

# Import shared state first (to avoid circular imports)
from .state import pending_orders, user_payment_info

from .commands import start, help_command
from .messages import handle_message, handle_button_press
from .callbacks import button_callback
from .payments import (
    handle_setup_payment_method,
    handle_setup_payment_method_inline,
    handle_setup_bank_selection,
    handle_setup_ewallet_selection,
    handle_setup_bank_selected,
    handle_setup_ewallet_selected,
    handle_confirm_setup_payment_data
)
from .transactions import (
    handle_transaction_history,
    handle_history_page_callback,
    send_transaction_page,
    handle_ton_sent,
    handle_start_sell_ton,
    handle_payment_proof
)
from .referrals import (
    handle_referral_balance,
    handle_withdrawal_request,
    handle_confirm_withdrawal
)
from .admin import (
    handle_owner_stats,
    handle_owner_stats_refresh,
    handle_admin_confirmation,
    handle_admin_withdrawal_confirmation,
    handle_public_stats
)
from .broadcast import (
    handle_broadcast_command,
    handle_broadcast_with_image,
    handle_broadcast_callback
)
from .errors import error_handler

__all__ = [
    # Commands
    'start',
    'help_command',
    # Messages
    'handle_message',
    'handle_button_press',
    # Callbacks
    'button_callback',
    # Payments
    'handle_setup_payment_method',
    'handle_setup_payment_method_inline',
    'handle_setup_bank_selection',
    'handle_setup_ewallet_selection',
    'handle_setup_bank_selected',
    'handle_setup_ewallet_selected',
    'handle_confirm_setup_payment_data',
    # Transactions
    'handle_transaction_history',
    'handle_history_page_callback',
    'send_transaction_page',
    'handle_ton_sent',
    'handle_start_sell_ton',
    'handle_payment_proof',
    # Referrals
    'handle_referral_balance',
    'handle_withdrawal_request',
    'handle_confirm_withdrawal',
    # Admin
    'handle_owner_stats',
    'handle_owner_stats_refresh',
    'handle_admin_confirmation',
    'handle_admin_withdrawal_confirmation',
    'handle_public_stats',
    # Broadcast
    'handle_broadcast_command',
    'handle_broadcast_with_image',
    'handle_broadcast_callback',
    # Errors
    'error_handler',
    # State
    'pending_orders',
    'user_payment_info',
]
