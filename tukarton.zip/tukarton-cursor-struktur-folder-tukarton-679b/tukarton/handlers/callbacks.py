"""
Callback query handlers untuk TukarTON bot
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import MIN_WITHDRAWAL_AMOUNT, COPYRIGHT_TEXT
from ..constants import get_text
from ..database import get_referral_stats

from .state import pending_orders, user_payment_info
from .payments import (
    handle_setup_payment_method_inline,
    handle_setup_bank_selection,
    handle_setup_ewallet_selection,
    handle_setup_bank_selected,
    handle_setup_ewallet_selected,
    handle_confirm_setup_payment_data
)
from .transactions import (
    handle_history_page_callback,
    handle_ton_sent,
    handle_start_sell_ton
)
from .referrals import handle_withdrawal_request, handle_confirm_withdrawal
from .admin import handle_owner_stats_refresh
from .broadcast import handle_broadcast_callback

logger = logging.getLogger(__name__)


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk callback tombol inline"""
    query = update.callback_query
    user_id = query.from_user.id
    
    # Beberapa callback memerlukan custom answer
    callbacks_with_custom_answer = [
        "withdrawal_insufficient",
        "confirm_broadcast_yes",
        "confirm_broadcast_no"
    ]
    
    # Cek apakah callback ini memerlukan custom answer
    needs_custom_answer = any(query.data.startswith(cb) for cb in callbacks_with_custom_answer)
    
    if not needs_custom_answer:
        await query.answer()
    
    if query.data == "cancel":
        try:
            await query.message.delete()
        except:
            pass
        
        text = get_text('order_cancelled')
        await context.bot.send_message(chat_id=query.message.chat_id, text=text, parse_mode='HTML')
        
        context.user_data.clear()
        if user_id in user_payment_info:
            del user_payment_info[user_id]
        if user_id in pending_orders:
            del pending_orders[user_id]
    
    elif query.data.startswith("history_page_"):
        await handle_history_page_callback(query, context)
    
    elif query.data == "setup_payment_method":
        await handle_setup_payment_method_inline(query, context)
    
    elif query.data == "setup_bank":
        await handle_setup_bank_selection(query, context)
    
    elif query.data == "setup_ewallet":
        await handle_setup_ewallet_selection(query, context)
    
    elif query.data.startswith("setup_bank_"):
        bank_name = query.data.replace("setup_bank_", "")
        await handle_setup_bank_selected(query, context, bank_name)
    
    elif query.data.startswith("setup_ewallet_"):
        ewallet_name = query.data.replace("setup_ewallet_", "")
        await handle_setup_ewallet_selected(query, context, ewallet_name)
    
    elif query.data == "confirm_setup_yes":
        await handle_confirm_setup_payment_data(query, context)
    
    elif query.data == "confirm_setup_no":
        text = get_text('order_cancelled')
        try:
            await query.message.edit_text(text, parse_mode='HTML')
        except:
            pass
        context.user_data['payment_step'] = None
    
    elif query.data == "ton_sent_yes":
        await handle_ton_sent(query, context)
    
    elif query.data == "ton_sent_no":
        text = get_text('order_cancelled')
        try:
            await query.message.edit_text(text, parse_mode='HTML')
        except:
            pass
        if user_id in pending_orders:
            del pending_orders[user_id]
    
    elif query.data == "refresh_stats":
        await handle_owner_stats_refresh(query, context)
    
    elif query.data == "start_sell_ton":
        await handle_start_sell_ton(query, context)
    
    elif query.data == "withdrawal_request":
        await handle_withdrawal_request(query, context)
    
    elif query.data == "confirm_withdrawal_yes":
        await handle_confirm_withdrawal(query, context)
    
    elif query.data == "confirm_withdrawal_no":
        text = get_text('order_cancelled')
        try:
            await query.message.edit_text(text, parse_mode='HTML')
        except:
            pass
        context.user_data['withdrawal_pending'] = None
    
    elif query.data == "withdrawal_insufficient":
        # Tampilkan pesan saldo tidak cukup dengan respon yang jelas
        referral_stats = get_referral_stats(user_id)
        balance = referral_stats['referral_balance']
        
        # Tampilkan popup alert terlebih dahulu
        await query.answer(f"❌ Saldo tidak mencukupi! Minimal Rp {MIN_WITHDRAWAL_AMOUNT:,.0f}", show_alert=True)
        
        # Dapatkan informasi untuk menampilkan pesan lengkap
        bot_username = (await context.bot.get_me()).username
        total_referrals = referral_stats['total_referrals']
        
        # Buat pesan yang informatif tentang saldo tidak cukup
        insufficient_response = (
            f"❌ <b>Saldo Tidak Mencukupi untuk Penarikan</b>\n\n"
            f"💵 <b>Saldo Anda saat ini:</b> Rp {balance:,.0f}\n"
            f"📊 <b>Minimal Penarikan:</b> Rp {MIN_WITHDRAWAL_AMOUNT:,.0f}\n"
            f"📉 <b>Kekurangan:</b> Rp {(MIN_WITHDRAWAL_AMOUNT - balance):,.0f}\n\n"
            f"👥 <b>Total Rujukan:</b> {total_referrals} orang\n\n"
            f"💡 <b>Tips untuk mencapai minimal penarikan:</b>\n"
            f"• Bagikan link rujukan Anda ke teman-teman\n"
            f"• Dapatkan 0.3% dari setiap transaksi rujukan\n\n"
            f"🔗 <b>Link Rujukan Anda:</b>\n"
            f"<code>https://t.me/{bot_username}?start=ref_{user_id}</code>\n\n"
            f"<i>Kumpulkan lebih banyak rujukan untuk mencapai batas minimal!</i>"
            + COPYRIGHT_TEXT
        )
        
        # Tombol untuk kembali
        keyboard = [
            [InlineKeyboardButton("🔙 Kembali ke Saldo", callback_data="back_to_balance")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.message.edit_text(insufficient_response, reply_markup=reply_markup, parse_mode='HTML')
        except Exception as e:
            logger.error(f"Error showing insufficient balance message: {e}")
    
    elif query.data == "back_to_balance":
        # Kembali ke halaman saldo rujukan
        bot_username = (await context.bot.get_me()).username
        referral_stats = get_referral_stats(user_id)
        balance = referral_stats['referral_balance']
        total_referrals = referral_stats['total_referrals']
        
        balance_text = get_text('referral_balance',
                               balance=balance,
                               total_referrals=total_referrals,
                               bot_username=bot_username,
                               user_id=user_id)
        
        # Buat tombol Penarikan
        keyboard = []
        
        if balance >= MIN_WITHDRAWAL_AMOUNT:
            keyboard.append([InlineKeyboardButton("💸 Penarikan", callback_data="withdrawal_request")])
        else:
            keyboard.append([InlineKeyboardButton(f"💸 Penarikan (Min. Rp {MIN_WITHDRAWAL_AMOUNT:,.0f})", callback_data="withdrawal_insufficient")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.message.edit_text(balance_text, reply_markup=reply_markup, parse_mode='HTML')
        except Exception as e:
            logger.error(f"Error returning to balance page: {e}")
    
    elif query.data.startswith("confirm_broadcast_"):
        await handle_broadcast_callback(query, context)
