"""
Transaction handlers untuk TukarTON bot
"""

import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import COPYRIGHT_TEXT, OWNER_USER_ID, YOUR_TON_WALLET, MIN_TON
from ..constants import get_text
from ..database import (
    get_user,
    get_user_transactions,
    save_transaction
)
from ..utils import (
    get_ton_price,
    calculate_max_ton,
    format_datetime
)

from .state import pending_orders

logger = logging.getLogger(__name__)


async def send_transaction_page(message, context: ContextTypes.DEFAULT_TYPE, user_id: int, page: int, is_edit=False):
    """Kirim halaman riwayat transaksi dengan pagination"""
    items_per_page = 2
    offset = (page - 1) * items_per_page
    
    # Ambil semua transaksi
    all_transactions = get_user_transactions(user_id, limit=100)
    total_transactions = len(all_transactions)
    
    if total_transactions == 0:
        text = get_text('no_transactions')
        if is_edit:
            try:
                await message.edit_text(text, parse_mode='HTML')
            except:
                pass
        else:
            await message.reply_text(text, parse_mode='HTML')
        return
    
    # Ambil transaksi untuk halaman ini
    transactions = all_transactions[offset:offset + items_per_page]
    
    trans_list = []
    for trans in transactions:
        if trans['status'] == 'completed':
            status = "✅"
        elif trans['status'] == 'pending':
            status = "⏳"
        else:
            status = "❌"
        
        # Format ringkas
        trans_text = (
            f"{status} <code>{trans['order_id']}</code>\n"
            f"📅 {format_datetime(trans['created_at'])}\n"
            f"💎 {trans['ton_amount']} TON → 💰 Rp {trans['total']:,.0f}\n"
        )
        trans_list.append(trans_text)
    
    transactions_text = "\n".join(trans_list)
    
    total_pages = (total_transactions + items_per_page - 1) // items_per_page
    
    history_text = (
        f"📜 <b>Riwayat Transaksi</b>\n\n"
        f"{transactions_text}\n"
        f"📄 Halaman {page}/{total_pages} • Total: {total_transactions} transaksi"
        + COPYRIGHT_TEXT
    )
    
    # Buat tombol navigasi
    keyboard = []
    nav_buttons = []
    
    if page > 1:
        nav_buttons.append(InlineKeyboardButton("⬅️ Sebelumnya", callback_data=f"history_page_{page-1}"))
    
    nav_buttons.append(InlineKeyboardButton("🔄 Refresh", callback_data=f"history_page_{page}"))
    
    if page < total_pages:
        nav_buttons.append(InlineKeyboardButton("Selanjutnya ➡️", callback_data=f"history_page_{page+1}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    # Tombol quick jump (jika lebih dari 3 halaman)
    if total_pages > 3:
        jump_buttons = []
        if page != 1:
            jump_buttons.append(InlineKeyboardButton("⏮️ Pertama", callback_data="history_page_1"))
        if page != total_pages:
            jump_buttons.append(InlineKeyboardButton("Terakhir ⏭️", callback_data=f"history_page_{total_pages}"))
        if jump_buttons:
            keyboard.append(jump_buttons)
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if is_edit:
        try:
            await message.edit_text(history_text, reply_markup=reply_markup, parse_mode='HTML')
        except:
            pass
    else:
        await message.reply_text(history_text, reply_markup=reply_markup, parse_mode='HTML')


async def handle_transaction_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk menampilkan riwayat transaksi (halaman 1)"""
    user_id = update.effective_user.id
    page = 1
    await send_transaction_page(update.message, context, user_id, page, is_edit=False)


async def handle_history_page_callback(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk navigasi halaman riwayat"""
    user_id = query.from_user.id
    callback_data = query.data
    
    # Extract page number
    page = int(callback_data.split("_")[-1])
    
    await send_transaction_page(query.message, context, user_id, page, is_edit=True)


async def handle_ton_sent(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler ketika user klik sudah mengirim TON"""
    user_id = query.from_user.id
    
    if user_id not in pending_orders:
        await query.message.edit_text("❌ <i>Pesanan tidak ditemukan.</i>", parse_mode='HTML')
        return
    
    order_data = pending_orders[user_id]
    memo = order_data.get('memo', '')
    
    text = get_text('waiting_payment_proof', memo=memo)
    
    try:
        await query.message.edit_text(text, parse_mode='HTML')
    except:
        pass
    
    context.user_data['awaiting_proof'] = True


async def handle_start_sell_ton(query, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk tombol Jual TON setelah setup payment"""
    user_id = query.from_user.id
    
    price = await get_ton_price()
    
    # Hitung maksimal TON
    user_info = get_user(user_id)
    max_ton = calculate_max_ton(price, user_info['payment_method_type'], user_info['payment_method'])
    
    from ..config import MAX_TRANSACTION_IDR
    input_text = get_text('input_ton_amount', 
                         price=price, 
                         min_ton=MIN_TON,
                         max_ton=max_ton,
                         max_idr=MAX_TRANSACTION_IDR)
    
    keyboard = [[InlineKeyboardButton("❌ Batalkan", callback_data="cancel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await query.message.edit_text(input_text, reply_markup=reply_markup, parse_mode='HTML')
    except:
        pass
    
    context.user_data['awaiting_ton_amount'] = True


async def handle_payment_proof(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk foto bukti transfer"""
    user_id = update.effective_user.id
    user = update.effective_user
    
    if user_id not in pending_orders:
        await update.message.reply_text("❌ <i>Tidak ada pesanan aktif.</i>", parse_mode='HTML')
        return
    
    order_data = pending_orders[user_id]
    order_id = order_data['order_id']
    
    confirm_text = get_text('proof_received',
                           ton_amount=order_data['ton_amount'],
                           total=order_data['total'],
                           payment_method=order_data['payment_method'],
                           order_id=order_id)
    
    await update.message.reply_text(confirm_text, parse_mode='HTML')
    
    save_transaction(order_data, user_id, user.username, user.first_name)
    
    user_info = f"{user.first_name}"
    if user.username:
        user_info += f" (@{user.username})"
    
    payment_info = (
        f"{'🏦 Bank' if order_data['payment_method_type'] == 'bank' else '📱 E-Wallet'}: {order_data['payment_method']}\n"
        f"👤 <b>Nama:</b> {order_data['account_name']}\n"
        f"🔢 <b>Nomor:</b> <code>{order_data['account_number']}</code>"
    )
    
    admin_text = get_text('admin_notification',
                         user_info=user_info,
                         user_id=user_id,
                         ton_amount=order_data['ton_amount'],
                         memo=order_data.get('memo', ''),
                         total=order_data['total'],
                         payment_info=payment_info,
                         order_id=order_id)
    
    try:
        photo = update.message.photo[-1]
        await context.bot.send_photo(
            chat_id=OWNER_USER_ID,
            photo=photo.file_id,
            caption=admin_text,
            parse_mode='HTML'
        )
        
        logger.info(f"Bukti transfer diterima dari user {user_id}, order {order_id}")
        
    except Exception as e:
        logger.error(f"Gagal kirim notifikasi ke owner: {e}")
    
    del pending_orders[user_id]
    context.user_data.clear()
