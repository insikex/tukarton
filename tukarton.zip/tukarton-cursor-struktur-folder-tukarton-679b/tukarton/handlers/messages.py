"""
Message handlers untuk TukarTON bot
"""

import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from ..config import (
    OWNER_USER_ID,
    MIN_TON,
    MAX_TRANSACTION_IDR,
    YOUR_TON_WALLET,
    COPYRIGHT_TEXT
)
from ..constants import get_text
from ..database import get_user
from ..utils import (
    fetch_ton_price,
    get_ton_price,
    check_user_has_payment_method,
    calculate_max_ton,
    get_payment_fee,
    generate_order_id,
    get_memo_from_order_id,
    get_main_button_keyboard
)

from .state import pending_orders, user_payment_info
from .payments import handle_setup_payment_method
from .transactions import handle_transaction_history, handle_payment_proof
from .referrals import handle_referral_balance
from .admin import handle_owner_stats, handle_admin_confirmation, handle_admin_withdrawal_confirmation, handle_public_stats

logger = logging.getLogger(__name__)


async def handle_button_press(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk tombol tekan dari keyboard"""
    user_id = update.effective_user.id
    text = update.message.text
    
    if text == "💎 Jual TON":
        if not check_user_has_payment_method(user_id):
            setup_text = get_text('setup_payment_required')
            keyboard = [[InlineKeyboardButton("💳 Atur Pembayaran", callback_data="setup_payment_method")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(setup_text, reply_markup=reply_markup, parse_mode='HTML')
            return
        
        await fetch_ton_price()
        price = await get_ton_price()
        
        # Hitung maksimal TON berdasarkan metode pembayaran user
        user_info = get_user(user_id)
        max_ton = calculate_max_ton(price, user_info['payment_method_type'], user_info['payment_method'])
        
        input_text = get_text('input_ton_amount', 
                             price=price, 
                             min_ton=MIN_TON,
                             max_ton=max_ton,
                             max_idr=MAX_TRANSACTION_IDR)
        
        keyboard = [[InlineKeyboardButton("❌ Batalkan", callback_data="cancel")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        sent_msg = await update.message.reply_text(input_text, reply_markup=reply_markup, parse_mode='HTML')
        context.user_data['awaiting_ton_amount'] = True
        context.user_data['last_message_id'] = sent_msg.message_id
    
    elif text == "💳 Atur Pembayaran":
        await handle_setup_payment_method(update, context)
    
    elif text == "ℹ️ Informasi":
        await fetch_ton_price()
        price = await get_ton_price()
        info_text = get_text('help_text', price=price)
        await update.message.reply_text(info_text, parse_mode='HTML')
    
    elif text == "📊 Statistik":
        await handle_public_stats(update, context)
    
    elif text == "📜 Riwayat":
        await handle_transaction_history(update, context)
    
    elif text == "💰 Saldo":
        await handle_referral_balance(update, context)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk pesan teks dan foto"""
    user_id = update.effective_user.id
    
    # Handle foto terlebih dahulu
    if update.message.photo:
        if context.user_data.get('awaiting_proof'):
            await handle_payment_proof(update, context)
            return
        else:
            # Foto dikirim di luar konteks transaksi
            await update.message.reply_text(
                "📷 <i>Foto diterima, tapi saat ini tidak ada transaksi yang memerlukan bukti transfer.</i>\n\n"
                "💡 <b>Gunakan menu di bawah untuk memulai transaksi.</b>",
                parse_mode='HTML',
                reply_markup=get_main_button_keyboard()
            )
            return
    
    # Pastikan text tidak None sebelum melanjutkan
    text = update.message.text
    if not text:
        return
    
    # Jika user sedang menunggu bukti foto tapi mengirim teks
    if context.user_data.get('awaiting_proof'):
        await update.message.reply_text(get_text('please_send_photo'), parse_mode='HTML')
        return
    
    button_texts = [
        "💎 Jual TON",
        "💳 Atur Pembayaran",
        "📊 Statistik",
        "ℹ️ Informasi",
        "📜 Riwayat",
        "💰 Saldo"
    ]
    
    if text in button_texts:
        await handle_button_press(update, context)
        return
    
    if user_id == OWNER_USER_ID:
        if text.lower() == 'stats':
            await handle_owner_stats(update, context)
            return
        elif text.lower().startswith('selesai '):
            await handle_admin_confirmation(update, context)
            return
        elif text.lower().startswith('bayarwd '):
            await handle_admin_withdrawal_confirmation(update, context)
            return
    
    payment_step = context.user_data.get('payment_step')
    
    if payment_step == 'setup_awaiting_name':
        user_payment_info[user_id]['setup_account_name'] = text
        
        method = user_payment_info[user_id]['setup_method']
        name = text
        
        response_text = get_text('input_account_number', method=method, name=name)
        await update.message.reply_text(response_text, parse_mode='HTML')
        
        context.user_data['payment_step'] = 'setup_awaiting_number'
        return
    
    elif payment_step == 'setup_awaiting_number':
        user_payment_info[user_id]['setup_account_number'] = text
        
        payment_data = user_payment_info[user_id]
        
        confirm_text = get_text('confirm_payment_info',
                               method=payment_data['setup_method'],
                               name=payment_data['setup_account_name'],
                               number=payment_data['setup_account_number'])
        
        keyboard = [
            [InlineKeyboardButton("✅ Ya, Benar", callback_data="confirm_setup_yes")],
            [InlineKeyboardButton("❌ Tidak, Batalkan", callback_data="confirm_setup_no")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(confirm_text, reply_markup=reply_markup, parse_mode='HTML')
        
        context.user_data['payment_step'] = None
        return
    
    if context.user_data.get('awaiting_ton_amount'):
        try:
            ton_amount = float(update.message.text.replace(',', '.'))
            
            if ton_amount < MIN_TON:
                await update.message.reply_text(get_text('invalid_amount', min_ton=MIN_TON), parse_mode='HTML')
                return
            
            price = await get_ton_price()
            
            # Validasi maksimal TON
            user_info = get_user(user_id)
            max_ton = calculate_max_ton(price, user_info['payment_method_type'], user_info['payment_method'])
            
            if ton_amount > max_ton:
                await update.message.reply_text(
                    get_text('invalid_max_amount', max_ton=max_ton, max_idr=MAX_TRANSACTION_IDR), 
                    parse_mode='HTML'
                )
                return
            
            subtotal = ton_amount * price
            
            payment_method_type = user_info.get('payment_method_type')
            payment_method = user_info.get('payment_method')
            fee = get_payment_fee(payment_method_type, payment_method)
            
            total = subtotal - fee
            
            order_id = generate_order_id()
            memo = get_memo_from_order_id(order_id)
            
            pending_orders[user_id] = {
                'order_id': order_id,
                'memo': memo,
                'ton_amount': ton_amount,
                'price_per_ton': price,
                'fee': fee,
                'total': total,
                'payment_method_type': payment_method_type,
                'payment_method': payment_method,
                'account_name': user_info.get('account_name'),
                'account_number': user_info.get('account_number'),
                'timestamp': datetime.now()
            }
            
            try:
                if 'last_message_id' in context.user_data:
                    await context.bot.delete_message(
                        chat_id=update.effective_chat.id,
                        message_id=context.user_data['last_message_id']
                    )
            except:
                pass
            
            try:
                await update.message.delete()
            except:
                pass
            
            instruction_text = get_text('send_ton_instruction',
                                       ton_amount=ton_amount,
                                       price_per_ton=price,
                                       fee=fee,
                                       total=total,
                                       wallet=YOUR_TON_WALLET,
                                       memo=memo)
            
            ton_deeplink = f"ton://transfer/{YOUR_TON_WALLET}?amount={int(ton_amount * 1000000000)}&text={memo}"
            
            keyboard = [
                [InlineKeyboardButton("💎 Bayar Sekarang", url=ton_deeplink)],
                [InlineKeyboardButton("✅ Sudah Kirim", callback_data="ton_sent_yes")],
                [InlineKeyboardButton("❌ Batalkan", callback_data="ton_sent_no")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=instruction_text,
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
            context.user_data['awaiting_ton_amount'] = False
            
        except ValueError:
            await update.message.reply_text(get_text('invalid_number'), parse_mode='HTML')
    else:
        # Pesan tidak dikenali, tampilkan bantuan singkat
        fallback_text = (
            "🤖 <i>Pesan tidak dikenali.</i>\n\n"
            "💡 <b>Gunakan menu di bawah untuk:</b>\n"
            "• 💎 <b>Jual TON</b> - Jual Toncoin Anda\n"
            "• 💳 <b>Atur Pembayaran</b> - Setup metode pembayaran\n"
            "• 📜 <b>Riwayat</b> - Lihat transaksi\n"
            "• 💰 <b>Saldo</b> - Cek saldo rujukan\n"
            "• 📊 <b>Statistik</b> - Lihat statistik bot\n"
            "• ℹ️ <b>Informasi</b> - Info lebih lanjut\n\n"
            "<i>Atau ketik /start untuk memulai ulang.</i>"
            + COPYRIGHT_TEXT
        )
        await update.message.reply_text(
            fallback_text, 
            parse_mode='HTML',
            reply_markup=get_main_button_keyboard()
        )
