"""
Operasi database untuk transaksi
"""

from .connection import get_connection
from .referrals import process_referral_earning


def save_transaction(order_data, user_id, username, first_name):
    """Simpan transaksi ke database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO transactions (
            order_id, user_id, ton_amount, price_per_ton, fee, total,
            payment_method_type, payment_method, account_name, account_number,
            memo, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ''', (
        order_data['order_id'],
        user_id,
        order_data['ton_amount'],
        order_data['price_per_ton'],
        order_data['fee'],
        order_data['total'],
        order_data['payment_method_type'],
        order_data['payment_method'],
        order_data['account_name'],
        order_data['account_number'],
        order_data.get('memo', '')
    ))
    
    conn.commit()
    conn.close()


def get_transaction(order_id):
    """Ambil data transaksi"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT t.*, u.username, u.first_name
        FROM transactions t
        JOIN users u ON t.user_id = u.user_id
        WHERE t.order_id = ?
    ''', (order_id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return {
            'order_id': row[1],
            'user_id': row[2],
            'ton_amount': row[3],
            'price_per_ton': row[4],
            'fee': row[5],
            'total': row[6],
            'payment_method_type': row[7],
            'payment_method': row[8],
            'account_name': row[9],
            'account_number': row[10],
            'memo': row[11],
            'status': row[12],
            'username': row[15],
            'first_name': row[16]
        }
    return None


def get_user_transactions(user_id, limit=100):
    """Ambil riwayat transaksi user"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT order_id, ton_amount, price_per_ton, total, status, 
               created_at, completed_at, payment_method
        FROM transactions 
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
    ''', (user_id, limit))
    
    rows = cursor.fetchall()
    conn.close()
    
    transactions = []
    for row in rows:
        transactions.append({
            'order_id': row[0],
            'ton_amount': row[1],
            'price_per_ton': row[2],
            'total': row[3],
            'status': row[4],
            'created_at': row[5],
            'completed_at': row[6],
            'payment_method': row[7]
        })
    
    return transactions


def get_user_stats(user_id):
    """Ambil statistik transaksi user"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM transactions WHERE user_id = ?', (user_id,))
    total_trans = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM transactions WHERE user_id = ? AND status = 'completed'", (user_id,))
    completed_trans = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM transactions WHERE user_id = ? AND status = 'pending'", (user_id,))
    pending_trans = cursor.fetchone()[0]
    
    cursor.execute("SELECT SUM(ton_amount) FROM transactions WHERE user_id = ? AND status = 'completed'", (user_id,))
    total_ton = cursor.fetchone()[0] or 0
    
    cursor.execute("SELECT SUM(total) FROM transactions WHERE user_id = ? AND status = 'completed'", (user_id,))
    total_idr = cursor.fetchone()[0] or 0
    
    conn.close()
    
    return {
        'total_transactions': total_trans,
        'completed_transactions': completed_trans,
        'pending_transactions': pending_trans,
        'total_ton_sold': total_ton,
        'total_idr_received': total_idr
    }


def complete_transaction(order_id):
    """Tandai transaksi sebagai selesai"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE transactions 
        SET status = 'completed', completed_at = CURRENT_TIMESTAMP
        WHERE order_id = ?
    ''', (order_id,))
    
    conn.commit()
    conn.close()
    
    # Proses penghasilan referral setelah transaksi selesai
    transaction = get_transaction(order_id)
    if transaction:
        user_id = transaction['user_id']
        total_amount = transaction['total']
        process_referral_earning(user_id, total_amount)


def get_statistics():
    """Ambil statistik dari database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM users')
    total_users = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM transactions WHERE status = 'completed'")
    completed_transactions = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM transactions WHERE status = 'pending'")
    pending_transactions = cursor.fetchone()[0]
    
    conn.close()
    
    return {
        'total_users': total_users,
        'completed_transactions': completed_transactions,
        'pending_transactions': pending_transactions
    }
