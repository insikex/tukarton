"""
Operasi database untuk withdrawal/penarikan
"""

import logging
from .connection import get_connection

logger = logging.getLogger(__name__)


def save_withdrawal_request(user_id: int, amount: float, payment_method: str, 
                           account_name: str, account_number: str) -> int:
    """Simpan permintaan penarikan"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO withdrawal_requests 
            (user_id, amount, payment_method, account_name, account_number)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, amount, payment_method, account_name, account_number))
        
        request_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return request_id
    except Exception as e:
        logger.error(f"Error saving withdrawal request: {e}")
        conn.close()
        return None


def get_withdrawal_request(request_id: int) -> dict:
    """Ambil data permintaan penarikan berdasarkan ID"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT wr.id, wr.user_id, wr.amount, wr.payment_method, 
                   wr.account_name, wr.account_number, wr.status, wr.created_at,
                   u.username, u.first_name
            FROM withdrawal_requests wr
            JOIN users u ON wr.user_id = u.user_id
            WHERE wr.id = ?
        ''', (request_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'user_id': row[1],
                'amount': row[2],
                'payment_method': row[3],
                'account_name': row[4],
                'account_number': row[5],
                'status': row[6],
                'created_at': row[7],
                'username': row[8],
                'first_name': row[9]
            }
        return None
    except Exception as e:
        logger.error(f"Error getting withdrawal request: {e}")
        conn.close()
        return None


def complete_withdrawal_request(request_id: int) -> bool:
    """Tandai permintaan penarikan sebagai selesai"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE withdrawal_requests 
            SET status = 'completed', processed_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (request_id,))
        
        if cursor.rowcount > 0:
            conn.commit()
            conn.close()
            logger.info(f"Withdrawal request {request_id} marked as completed")
            return True
        else:
            conn.close()
            return False
    except Exception as e:
        logger.error(f"Error completing withdrawal request: {e}")
        conn.close()
        return False
