"""
Operasi database untuk broadcast
"""

import logging
from .connection import get_connection

logger = logging.getLogger(__name__)


def get_all_user_ids() -> list:
    """Ambil semua user_id dari database untuk broadcast"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT user_id FROM users')
        rows = cursor.fetchall()
        conn.close()
        return [row[0] for row in rows]
    except Exception as e:
        logger.error(f"Error getting all user ids: {e}")
        conn.close()
        return []


def save_broadcast_log(admin_id: int, message: str, total_users: int, 
                       success_count: int, failed_count: int) -> int:
    """Simpan log broadcast ke database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        # Buat tabel jika belum ada
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS broadcast_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER NOT NULL,
                message TEXT,
                total_users INTEGER,
                success_count INTEGER,
                failed_count INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            INSERT INTO broadcast_logs (admin_id, message, total_users, success_count, failed_count)
            VALUES (?, ?, ?, ?, ?)
        ''', (admin_id, message[:500], total_users, success_count, failed_count))
        
        log_id = cursor.lastrowid
        conn.commit()
        conn.close()
        logger.info(f"Broadcast log saved: ID {log_id}, sent to {success_count}/{total_users} users")
        return log_id
    except Exception as e:
        logger.error(f"Error saving broadcast log: {e}")
        conn.close()
        return None
