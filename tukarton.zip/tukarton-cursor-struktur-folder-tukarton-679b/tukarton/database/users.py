"""
Operasi database untuk user
"""

import sqlite3
from .connection import get_connection


def save_user(user_id, username=None, first_name=None, payment_info=None):
    """Simpan atau update data user"""
    conn = get_connection()
    cursor = conn.cursor()
    
    if payment_info:
        cursor.execute('''
            INSERT INTO users (user_id, username, first_name, payment_method_type, 
                             payment_method, account_name, account_number, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                first_name = excluded.first_name,
                payment_method_type = excluded.payment_method_type,
                payment_method = excluded.payment_method,
                account_name = excluded.account_name,
                account_number = excluded.account_number,
                updated_at = CURRENT_TIMESTAMP
        ''', (user_id, username, first_name, 
              payment_info.get('payment_method_type'),
              payment_info.get('payment_method'),
              payment_info.get('account_name'),
              payment_info.get('account_number')))
    else:
        cursor.execute('''
            INSERT INTO users (user_id, username, first_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                first_name = excluded.first_name,
                updated_at = CURRENT_TIMESTAMP
        ''', (user_id, username, first_name))
    
    conn.commit()
    conn.close()


def get_user(user_id):
    """Ambil data user dari database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT user_id, username, first_name, payment_method_type, 
               payment_method, account_name, account_number, created_at
        FROM users WHERE user_id = ?
    ''', (user_id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return {
            'user_id': row[0],
            'username': row[1],
            'first_name': row[2],
            'payment_method_type': row[3],
            'payment_method': row[4],
            'account_name': row[5],
            'account_number': row[6],
            'created_at': row[7]
        }
    return None
