"""
Operasi database untuk sistem referral
"""

import logging
from .connection import get_connection
from ..config import REFERRAL_PERCENTAGE

logger = logging.getLogger(__name__)


def save_referral(referrer_id: int, referred_id: int) -> bool:
    """Simpan hubungan referral ke database"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        # Cek apakah referred_id sudah pernah direferensikan
        cursor.execute('SELECT id FROM referrals WHERE referred_id = ?', (referred_id,))
        if cursor.fetchone():
            conn.close()
            return False  # Sudah pernah direferensikan
        
        # Cek apakah referrer_id sama dengan referred_id
        if referrer_id == referred_id:
            conn.close()
            return False
        
        # Simpan referral
        cursor.execute('''
            INSERT INTO referrals (referrer_id, referred_id)
            VALUES (?, ?)
        ''', (referrer_id, referred_id))
        
        # Update atau buat record referral_earnings untuk referrer
        cursor.execute('''
            INSERT INTO referral_earnings (user_id, total_referrals)
            VALUES (?, 1)
            ON CONFLICT(user_id) DO UPDATE SET
                total_referrals = total_referrals + 1,
                updated_at = CURRENT_TIMESTAMP
        ''', (referrer_id,))
        
        conn.commit()
        conn.close()
        logger.info(f"Referral saved: {referrer_id} referred {referred_id}")
        return True
    except Exception as e:
        logger.error(f"Error saving referral: {e}")
        conn.close()
        return False


def get_referrer(referred_id: int) -> int:
    """Dapatkan user_id dari referrer berdasarkan referred_id"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT referrer_id FROM referrals WHERE referred_id = ?', (referred_id,))
    row = cursor.fetchone()
    conn.close()
    
    return row[0] if row else None


def add_referral_earning(referrer_id: int, amount: float) -> bool:
    """Tambahkan penghasilan referral ke saldo referrer"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO referral_earnings (user_id, referral_balance)
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                referral_balance = referral_balance + ?,
                updated_at = CURRENT_TIMESTAMP
        ''', (referrer_id, amount, amount))
        
        conn.commit()
        conn.close()
        logger.info(f"Added referral earning: {amount} to user {referrer_id}")
        return True
    except Exception as e:
        logger.error(f"Error adding referral earning: {e}")
        conn.close()
        return False


def get_referral_stats(user_id: int) -> dict:
    """Dapatkan statistik referral untuk user"""
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT referral_balance, total_referrals
        FROM referral_earnings
        WHERE user_id = ?
    ''', (user_id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return {
            'referral_balance': row[0] or 0,
            'total_referrals': row[1] or 0
        }
    return {
        'referral_balance': 0,
        'total_referrals': 0
    }


def process_referral_earning(transaction_user_id: int, transaction_amount: float) -> bool:
    """Proses penghasilan referral saat transaksi selesai"""
    referrer_id = get_referrer(transaction_user_id)
    
    if referrer_id:
        # Hitung 0.3% dari transaksi
        referral_earning = transaction_amount * (REFERRAL_PERCENTAGE / 100)
        return add_referral_earning(referrer_id, referral_earning)
    
    return False


def deduct_referral_balance(user_id: int, amount: float) -> bool:
    """Kurangi saldo referral setelah penarikan"""
    conn = get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE referral_earnings
            SET referral_balance = referral_balance - ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE user_id = ? AND referral_balance >= ?
        ''', (amount, user_id, amount))
        
        if cursor.rowcount > 0:
            conn.commit()
            conn.close()
            return True
        else:
            conn.close()
            return False
    except Exception as e:
        logger.error(f"Error deducting referral balance: {e}")
        conn.close()
        return False
