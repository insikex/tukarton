"""
Database module untuk TukarTON bot
Mengelola semua operasi database SQLite
"""

from .connection import init_database, get_connection
from .users import save_user, get_user
from .transactions import (
    save_transaction,
    get_transaction,
    get_user_transactions,
    get_user_stats,
    complete_transaction,
    get_statistics
)
from .referrals import (
    save_referral,
    get_referrer,
    add_referral_earning,
    get_referral_stats,
    process_referral_earning,
    deduct_referral_balance
)
from .withdrawals import (
    save_withdrawal_request,
    get_withdrawal_request,
    complete_withdrawal_request
)
from .broadcast import (
    get_all_user_ids,
    save_broadcast_log
)

__all__ = [
    # Connection
    'init_database',
    'get_connection',
    # Users
    'save_user',
    'get_user',
    # Transactions
    'save_transaction',
    'get_transaction',
    'get_user_transactions',
    'get_user_stats',
    'complete_transaction',
    'get_statistics',
    # Referrals
    'save_referral',
    'get_referrer',
    'add_referral_earning',
    'get_referral_stats',
    'process_referral_earning',
    'deduct_referral_balance',
    # Withdrawals
    'save_withdrawal_request',
    'get_withdrawal_request',
    'complete_withdrawal_request',
    # Broadcast
    'get_all_user_ids',
    'save_broadcast_log',
]
